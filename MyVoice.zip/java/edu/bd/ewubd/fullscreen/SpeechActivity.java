package edu.bd.ewubd.fullscreen;

import android.content.Context;
import android.content.Intent;
import android.content.Loader;
import android.media.SoundPool;
import android.os.Bundle;
import android.speech.tts.TextToSpeech;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.speech.tts.TextToSpeech;
import android.speech.tts.TextToSpeech.OnInitListener;
import android.widget.Toast;

import java.util.Locale;

/**
 * Created by fuadk on 11/25/2016.
 */

public class SpeechActivity extends AppCompatActivity {

    EditText tvSpeach;
    ImageButton speak;
    TextToSpeech tts;
    Button stopSpeak,clear;
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.speech_layout);
        Toast toast = Toast.makeText(this.getApplicationContext(), "Please wait 4 Second to load Text-to-Speech Engine", Toast.LENGTH_SHORT);
        toast.show();
        tvSpeach = (EditText) findViewById(R.id.tvSpeak);
        speak = (ImageButton) findViewById(R.id.speak);
        stopSpeak = (Button) findViewById(R.id.stopSpeech);
        clear = (Button) findViewById(R.id.clearButton);
        //Use below initialize methord and ConvertTextToSpeech(String text) methord for initialize TextToSpeech and use this in every Speech to text Activity Class
        tts=new TextToSpeech(SpeechActivity.this, new TextToSpeech.OnInitListener() {

            @Override
            public void onInit(int status) {
                // TODO Auto-generated method stub
                if(status == TextToSpeech.SUCCESS){
                    int result=tts.setLanguage(Locale.US);
                    if(result==TextToSpeech.LANG_MISSING_DATA ||
                            result==TextToSpeech.LANG_NOT_SUPPORTED){
                        Log.e("error", "This Language is not supported");
                    }
                    else{
                       // ConvertTextToSpeech();
                    }
                }
                else
                    Log.e("error", "Initilization Failed!");
            }
        });

    }


    public void talk(View v){
        String text = tvSpeach.getText().toString();
        ConvertTextToSpeech(text);

    }
    public void stopSpeak(View v){
        ConvertTextToSpeech("Speech Terminated");
    }
    public void clear(View v){
        tvSpeach.setText("");
    }

    private void ConvertTextToSpeech(String text) {
        // TODO Auto-generated method stub

        if(text==null||"".equals(text))
        {
            text = "Content not available";
            tts.speak(text, TextToSpeech.QUEUE_FLUSH, null);
        }else
            tts.speak(text, TextToSpeech.QUEUE_FLUSH, null);
    }

    @Override
    public void onDestroy(){
        if(tts !=null){
            tts.stop();
            tts.shutdown();
        }
        super.onDestroy();
    }


}
