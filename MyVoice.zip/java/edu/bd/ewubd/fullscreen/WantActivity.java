package edu.bd.ewubd.fullscreen;

import android.speech.tts.TextToSpeech;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.Toast;

import java.util.Locale;

public class WantActivity extends AppCompatActivity {
    TextToSpeech tts;
    Button ifh,iasb,iasc,iasd,dbu,sc,wad;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.activity_want);
        Toast toast = Toast.makeText(this.getApplicationContext(), "Please wait 4 Second to load Text-to-Speech Engine", Toast.LENGTH_SHORT);
        toast.show();
        ifh =(Button)findViewById(R.id.ifh);
        iasb =(Button)findViewById(R.id.iasb);
        iasc =(Button)findViewById(R.id.iasc);
        iasd =(Button)findViewById(R.id.iasd);
        dbu =(Button)findViewById(R.id.dbu);
        sc =(Button)findViewById(R.id.sc);
        wad =(Button)findViewById(R.id.wad);
        tts=new TextToSpeech(WantActivity.this, new TextToSpeech.OnInitListener() {

            @Override
            public void onInit(int status) {
                // TODO Auto-generated method stub
                if(status == TextToSpeech.SUCCESS){
                    int result=tts.setLanguage(Locale.US);
                    if(result==TextToSpeech.LANG_MISSING_DATA ||
                            result==TextToSpeech.LANG_NOT_SUPPORTED){
                        Log.e("error", "This Language is not supported");
                    }
                    else{
                        // ConvertTextToSpeech();
                    }
                }
                else
                    Log.e("error", "Initilization Failed!");
            }
        });
    }
    private void ConvertTextToSpeech(String text) {
        // TODO Auto-generated method stub

        if(text==null||"".equals(text))
        {
            text = "Content not available";
            tts.speak(text, TextToSpeech.QUEUE_FLUSH, null);
        }else
            tts.speak(text, TextToSpeech.QUEUE_FLUSH, null);
    }

    public void ifh(View v){
        ConvertTextToSpeech("i feel happy ");
    }
    public void iasb(View v){
        ConvertTextToSpeech("I am so bored");
    }
    public void iasc(View v){
        ConvertTextToSpeech("I am so curious");
    }
    public void iasd(View v){
        ConvertTextToSpeech("I am so disappointed");
    }
    public void dbu(View v){
        ConvertTextToSpeech("don't be upset");
    }
    public void sc(View v){
        ConvertTextToSpeech("stay claim");
    }
    public void wad(View v){
        ConvertTextToSpeech("We are delighted");
    }
}
