package edu.bd.ewubd.fullscreen;

import android.speech.tts.TextToSpeech;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.Toast;

import java.util.Locale;

public class CloseActivity extends AppCompatActivity {
    TextToSpeech tts;
    Button rtl,wt,dh,stp,idut;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.activity_close);
        Toast toast = Toast.makeText(this.getApplicationContext(), "Please wait 4 Second to load Text-to-Speech Engine", Toast.LENGTH_SHORT);
        toast.show();
        rtl =(Button)findViewById(R.id.rtl);
        wt =(Button)findViewById(R.id.wt);
        dh =(Button)findViewById(R.id.dh);
        stp =(Button)findViewById(R.id.stp);
        idut =(Button)findViewById(R.id.idut);
        tts=new TextToSpeech(CloseActivity.this, new TextToSpeech.OnInitListener() {

            @Override
            public void onInit(int status) {
                // TODO Auto-generated method stub
                if(status == TextToSpeech.SUCCESS){
                    int result=tts.setLanguage(Locale.US);
                    if(result==TextToSpeech.LANG_MISSING_DATA ||
                            result==TextToSpeech.LANG_NOT_SUPPORTED){
                        Log.e("error", "This Language is not supported");
                    }
                    else{
                        // ConvertTextToSpeech();
                    }
                }
                else
                    Log.e("error", "Initilization Failed!");
            }
        });
    }
    private void ConvertTextToSpeech(String text) {
        // TODO Auto-generated method stub

        if(text==null||"".equals(text))
        {
            text = "Content not available";
            tts.speak(text, TextToSpeech.QUEUE_FLUSH, null);
        }else
            tts.speak(text, TextToSpeech.QUEUE_FLUSH, null);
    }

public void rtl(View v){ ConvertTextToSpeech("Read this line ");}
    public void wt(View v){ ConvertTextToSpeech("write this  ");}
    public void dh(View v){ ConvertTextToSpeech("done homework");}
    public void aid(View v){ ConvertTextToSpeech("assingment is done");}
    public void stp(View v){ ConvertTextToSpeech("select the project ");}
    public void idut(View v){ ConvertTextToSpeech("i don't understand this");}
}
