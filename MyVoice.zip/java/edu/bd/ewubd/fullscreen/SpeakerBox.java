package edu.bd.ewubd.fullscreen;

import android.content.Context;
import android.media.AudioManager;
import android.speech.tts.TextToSpeech;
import android.util.Log;

import java.util.HashMap;
import java.util.Locale;

/**
 * Created by fuadk on 11/25/2016.
 */

public class SpeakerBox {
    private TextToSpeech tts;

    public class Speaker implements TextToSpeech.OnInitListener {

        private TextToSpeech tts;

        private boolean ready = false;

        private boolean allowed = false;

        public Speaker(Context context){
            tts = new TextToSpeech(context, this);
        }

        public boolean isAllowed(){
            return allowed;
        }

        public void allow(boolean allowed){
            this.allowed = allowed;
        }

        @Override
        public void onInit(int status) {
            // TODO Auto-generated method stub
            if(status == TextToSpeech.SUCCESS){
                int result=tts.setLanguage(Locale.US);
                if(result==TextToSpeech.LANG_MISSING_DATA ||
                        result==TextToSpeech.LANG_NOT_SUPPORTED){
                    Log.e("error", "This Language is not supported");
                }
                else{

                }
            }
            else
                Log.e("error", "Initilization Failed!");
        }
        public void ConvertTextToSpeech(String text) {
            // TODO Auto-generated method stub
            if(text==null||"".equals(text))
            {
                text = "Content not available";
                tts.speak(text, TextToSpeech.QUEUE_FLUSH, null);
            }else
                tts.speak(text, TextToSpeech.QUEUE_FLUSH, null);

        }


        public void pause(int duration){
            tts.playSilence(duration, TextToSpeech.QUEUE_ADD, null);
        }

        // Free up resources
        public void destroy(){
            tts.stop();
            tts.shutdown();
        }

    }

}
