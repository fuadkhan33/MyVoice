package edu.bd.ewubd.fullscreen;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.speech.tts.TextToSpeech;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.ImageButton;

import java.util.Locale;

/**
 * An example full-screen activity that shows and hides the system UI (i.e.
 * status bar and navigation/system bar) with user interaction.
 */
public class FullscreenActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        ImageButton speechButton;
        ImageButton catagoryButton,trackme;
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.activity_fullscreen);
        speechButton = (ImageButton) findViewById(R.id.speechButton);
        catagoryButton = (ImageButton) findViewById(R.id.catagoryButton);
        trackme = (ImageButton) findViewById(R.id.tracMeButton);

    }

    public void speakActivity(View v){
        Intent speechActivity = new Intent("INTENT.SPEECH_ACTIVITY");
        startActivity(speechActivity);
    }
    public void catagoryActivity(View v){
        Intent catagoryActivityi = new Intent("INTENT.CATAGORY_ACTIVITY");
        startActivity(catagoryActivityi);
    }
    public void locationActivity(View v){
        Intent catagoryActivityi = new Intent("INTENT.LOCATION_ACTIVITY");
        startActivity(catagoryActivityi);
    }
    public void signLanguageActivity(View v){
        Intent catagoryActivity = new Intent("INTENT.SIGNLANGUAGE_ACTIVITY");
        startActivity(catagoryActivity);
    }

}
