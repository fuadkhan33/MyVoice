package edu.bd.ewubd.fullscreen;

import android.content.Intent;
import android.os.Bundle;
import android.os.PersistableBundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Toast;

/**
 * Created by fuadk on 11/25/2016.
 */

public class CatagoryActivity extends AppCompatActivity{
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.catagory_activity);

    }
    public void LikeActivity(View v){
        Intent t = new Intent("INTENT.LIKE_ACTIVITY");
        startActivity(t);
    }
    public void DislikeActivity(View v){
        Intent t = new Intent("INTENT.DISLIKE_ACTIVITY");
        startActivity(t);
    }
    public void WantActivity(View v){
        Intent t = new Intent("INTENT.WANT_ACTIVITY");
        startActivity(t);
    }
    public void HelpActivity(View v){
        Intent t = new Intent("INTENT.HELP_ACTIVITY");
        startActivity(t);
    }
    public void OpenActivity(View v){
        Intent t = new Intent("INTENT.OPEN_ACTIVITY");
        startActivity(t);
    }
    public void CloseActivity(View v){
        Intent t = new Intent("INTENT.CLOSE_ACTIVITY");
        startActivity(t);
    }
    public void GreetingsActivity(View v){
        Intent t = new Intent("INTENT.GREETINGS_ACTIVITY");
        startActivity(t);
    }
    public void DirectionActivity(View v){
        Intent t = new Intent("INTENT.DIRECTION_ACTIVITY");
        startActivity(t);
    }
    public void SenceActivity(View v){
        Intent t = new Intent("INTENT.SENCE_ACTIVITY");
        startActivity(t);
    }
    public void OnoffActivity(View v){
        Intent t = new Intent("INTENT.ONOFF_ACTIVITY");
        startActivity(t);
    }
}
