package edu.bd.ewubd.fullscreen;

import android.speech.tts.TextToSpeech;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.Toast;

import java.util.Locale;

public class GreetingsActivity extends AppCompatActivity {
    TextToSpeech tts;
    Button pod,cygw,pbt,wch,pcw,pgt,wypt;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.activity_greetings);
        Toast toast = Toast.makeText(this.getApplicationContext(), "Please wait 4 Second to load Text-to-Speech Engine", Toast.LENGTH_SHORT);
        toast.show();
        pod =(Button)findViewById(R.id.pod);
        cygw =(Button)findViewById(R.id.cygw);
        pbt =(Button)findViewById(R.id.pbt);
        wch =(Button)findViewById(R.id.wch);
        pcw =(Button)findViewById(R.id.pcw);
        pgt =(Button)findViewById(R.id.pgt);
        wypt =(Button)findViewById(R.id.wypt);
        tts=new TextToSpeech(GreetingsActivity.this, new TextToSpeech.OnInitListener() {

            @Override
            public void onInit(int status) {
                // TODO Auto-generated method stub
                if(status == TextToSpeech.SUCCESS){
                    int result=tts.setLanguage(Locale.US);
                    if(result==TextToSpeech.LANG_MISSING_DATA ||
                            result==TextToSpeech.LANG_NOT_SUPPORTED){
                        Log.e("error", "This Language is not supported");
                    }
                    else{
                        // ConvertTextToSpeech();
                    }
                }
                else
                    Log.e("error", "Initilization Failed!");
            }
        });
    }
    private void ConvertTextToSpeech(String text) {
        // TODO Auto-generated method stub

        if(text==null||"".equals(text))
        {
            text = "Content not available";
            tts.speak(text, TextToSpeech.QUEUE_FLUSH, null);
        }else
            tts.speak(text, TextToSpeech.QUEUE_FLUSH, null);
    }

public void pod(View v){ConvertTextToSpeech("please open the door ");}
public void cygw(View v){ConvertTextToSpeech("Can  you give me a glass of water ");}
public void pbt(View v){ConvertTextToSpeech("please bring me that thing");}
public void wch(View v){ConvertTextToSpeech("would you came here");}
public void pcw(View v){ConvertTextToSpeech("please close the window");}
public void pgt(View v){ConvertTextToSpeech("please give me of those ");}
public void wypt(View v){ConvertTextToSpeech("will you please come tomorrow ");}

}
