package edu.bd.ewubd.fullscreen;

import android.speech.tts.TextToSpeech;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.Toast;

import java.util.Locale;

public class LikeActivity extends AppCompatActivity {
    TextToSpeech tts;
    Button hi,hello,howdo,gm,gn,ga,gno,wu,ntsy;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.activity_like);
        Toast toast = Toast.makeText(this.getApplicationContext(), "Please wait 4 Second to load Text-to-Speech Engine", Toast.LENGTH_SHORT);
        toast.show();
        hi=(Button) findViewById(R.id.hi);
        hello=(Button) findViewById(R.id.hello);
        howdo=(Button) findViewById(R.id.howdo);
        gm=(Button) findViewById(R.id.gm);
        gn=(Button) findViewById(R.id.gn);
        ga=(Button) findViewById(R.id.ga);
        gno=(Button) findViewById(R.id.gno);
        wu=(Button) findViewById(R.id.wu);
        ntsy=(Button) findViewById(R.id.ntsy);
        tts=new TextToSpeech(LikeActivity.this, new TextToSpeech.OnInitListener() {

            @Override
            public void onInit(int status) {
                // TODO Auto-generated method stub
                if(status == TextToSpeech.SUCCESS){
                    int result=tts.setLanguage(Locale.US);
                    if(result==TextToSpeech.LANG_MISSING_DATA ||
                            result==TextToSpeech.LANG_NOT_SUPPORTED){
                        Log.e("error", "This Language is not supported");
                    }
                    else{
                        // ConvertTextToSpeech();
                    }
                }
                else
                    Log.e("error", "Initilization Failed!");
            }
        });
    }
    private void ConvertTextToSpeech(String text) {
        // TODO Auto-generated method stub

        if(text==null||"".equals(text))
        {
            text = "Content not available";
            tts.speak(text, TextToSpeech.QUEUE_FLUSH, null);
        }else
            tts.speak(text, TextToSpeech.QUEUE_FLUSH, null);
    }
    public void hi(View v){
        ConvertTextToSpeech("Hi");
    }
    public void hello(View v){
        ConvertTextToSpeech("Hello");
    }
    public void howdo(View v){
        ConvertTextToSpeech("How do you do ?");
    }
    public void gm(View v){
        ConvertTextToSpeech("Good Morning");
    }
    public void gn(View v){
        ConvertTextToSpeech("Good Night");
    }
    public void ga(View v){
        ConvertTextToSpeech("Good afternoon");
    }
    public void gno(View v){
        ConvertTextToSpeech("Good noon");
    }
    public void wu(View v){
        ConvertTextToSpeech("What’s up");
    }
    public void ntsy(View v){
        ConvertTextToSpeech("Nice to see you");
    }


    @Override
    public void onPause(){
        if(tts !=null){
            tts.stop();
            tts.shutdown();
        }
        super.onPause();
    }
}
