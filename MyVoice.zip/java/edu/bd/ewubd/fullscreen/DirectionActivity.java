package edu.bd.ewubd.fullscreen;

import android.speech.tts.TextToSpeech;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.Toast;

import java.util.Locale;

public class DirectionActivity extends AppCompatActivity {
    TextToSpeech tts;
    Button gup,gwd,sd,ls,rs,gn,tw;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.activity_fullscreen);
        setContentView(R.layout.activity_direction);
        Toast toast = Toast.makeText(this.getApplicationContext(), "Please wait 4 Second to load Text-to-Speech Engine", Toast.LENGTH_SHORT);
        toast.show();
        gup = (Button)findViewById(R.id.gup) ;
        gwd = (Button)findViewById(R.id.gwd) ;
        sd = (Button)findViewById(R.id.sd) ;
        ls = (Button)findViewById(R.id.ls) ;
        rs = (Button)findViewById(R.id.rs) ;
        gn = (Button)findViewById(R.id.gn) ;
        tw = (Button)findViewById(R.id.tw) ;
        tts=new TextToSpeech(DirectionActivity.this, new TextToSpeech.OnInitListener() {

            @Override
            public void onInit(int status) {
                // TODO Auto-generated method stub
                if(status == TextToSpeech.SUCCESS){
                    int result=tts.setLanguage(Locale.US);
                    if(result==TextToSpeech.LANG_MISSING_DATA ||
                            result==TextToSpeech.LANG_NOT_SUPPORTED){
                        Log.e("error", "This Language is not supported");
                    }
                    else{
                        // ConvertTextToSpeech();
                    }
                }
                else
                    Log.e("error", "Initilization Failed!");
            }
        });
    }
    private void ConvertTextToSpeech(String text) {
        // TODO Auto-generated method stub

        if(text==null||"".equals(text))
        {
            text = "Content not available";
            tts.speak(text, TextToSpeech.QUEUE_FLUSH, null);
        }else
            tts.speak(text, TextToSpeech.QUEUE_FLUSH, null);
    }

public void gup(View v){ConvertTextToSpeech("go up ward ");}
public void gdw(View v){ConvertTextToSpeech("go down ward");}
public void sd(View v){ConvertTextToSpeech("sit down ");}
public void ls(View v){ConvertTextToSpeech("left side ");}
public void rs(View v){ConvertTextToSpeech("right side ");}
public void gn(View v){ConvertTextToSpeech("go north ");}
public void tw(View v){ConvertTextToSpeech("that way ");}
}
